import { useDispatch, useSelector } from "react-redux";
import { decrement, increment, reset } from "../reducer/slices/counterSlice";
import { selectCurrentPage, selectTotalPages, selectUsers } from "../reducer/selectors";
import { getAndStoreData } from "../reducer/thunks";
import { useEffect, useState } from "react";
import { NavigationComponent, UserDisplayComponent } from "../components";
import { LIST_SIZE } from "../constants";

export const Index = () => {
  const currentPage = useSelector(selectCurrentPage);
  const data = useSelector(selectUsers);
  const dispatch = useDispatch();

  const listToDisplay = data.slice(currentPage, currentPage + LIST_SIZE)

  console.log('>>>>>>>SI', listToDisplay, LIST_SIZE, currentPage)

  useEffect(() => {
    dispatch(getAndStoreData());
  }, []);

  return (
    <div className="flex flex-col">
      <p className="text-3xl font-bold">Current Page {currentPage}</p>
      <div>
        <h5 className="text-center ">Data</h5>

        <div className="list">
          <ul>
            {listToDisplay
              .map((userData) => <UserDisplayComponent key={userData.id} {...userData}/>)}
          </ul>
        </div>
      </div>
      <NavigationComponent />
    </div>
  );
};
