const fetchData = async () => {
  try {
    const data = await fetch("https://jsonplaceholder.typicode.com/posts").then(
      (res) => res.json()
    );
    return data;
  } catch (err) {
    console.log("Error in fetching the data", err);
    return [];
  }
};

export { fetchData };
