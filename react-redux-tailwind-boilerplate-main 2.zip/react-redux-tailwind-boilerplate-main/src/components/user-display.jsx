import { useDispatch, useSelector } from "react-redux";
import { selectDislikeRow, selectLikerow } from "../reducer/selectors";
import { dislikeRow, likeRow } from "../reducer/slices/counterSlice";
import PropTypes from 'prop-types'


export const UserDisplayComponent = ({ id, userId, title }) => {
  const dispatch = useDispatch()
  const likedItems = useSelector(selectLikerow)
  const dislikedItems = useSelector(selectDislikeRow)
  const like = () => dispatch(likeRow(id));

  const dislike = () => dispatch(dislikeRow(id));

  return (
    <li className="flex gap-1" key={id}>
      <span>{userId}</span>
      <span>{id}</span>
      <span>{title}</span>
      <button className="" onClick={like} style={{
        color: 'green',
        fontWeight: likedItems.includes(id)?900: 400
      }}>
        Like
      </button>
      <button className="" onClick={dislike}  style={{
        color: 'red',
        fontWeight: dislikedItems.includes(id)?900: 400
      }}>
        Dislike
      </button>
    </li>
  );
};

UserDisplayComponent.propTypes = {
  id: PropTypes.string.isRequired,
  userId: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
}


