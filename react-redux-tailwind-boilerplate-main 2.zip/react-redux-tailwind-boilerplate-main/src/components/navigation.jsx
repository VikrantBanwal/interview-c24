import { useDispatch, useSelector } from "react-redux";
import { selectCurrentPage, selectTotalPages } from "../reducer/selectors";
import { setPage } from "../reducer/slices/counterSlice";

export const NavigationComponent = () => {
  const currentPage = useSelector(selectCurrentPage);
  const totalPages = useSelector(selectTotalPages);

  const dispatch = useDispatch();

  const navigationHandler =
    (direction = 1) =>
    () => {
      const upcomingPage = currentPage + direction;
      if (upcomingPage < 0 || upcomingPage > totalPages) {
        return;
      }

      dispatch(setPage(upcomingPage));
    };

  return (
    <div className="flex ">
      <button className="text-3xl" onClick={navigationHandler(-1)}>
        Prev
      </button>
      <button className="text-3xl" onClick={navigationHandler(1)}>
        Next
      </button>
    </div>
  );
};
