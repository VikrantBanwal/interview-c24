export const selectUsers = (state) => state?.counter?.data ?? [];
export const selectCurrentPage = (state) => state?.counter?.currentPage;
export const selectTotalPages = (state) => state?.counter?.totalPages;
export const selectLikerow = (state) => state?.counter?.likedItems;
export const selectDislikeRow = (state) => state?.counter?.dislikedItems;
