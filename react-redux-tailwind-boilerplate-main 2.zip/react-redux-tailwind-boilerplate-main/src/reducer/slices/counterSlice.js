import { createSlice } from "@reduxjs/toolkit";
import { getAndStoreData } from "../thunks";
import {LIST_SIZE} from '../../constants'

const initialState = {
  data: [],
  status: null, // pending, fulfulled, error
  totalPages: 1,
  currentPage: 1,
  likedItems: [],
  dislikedItems: [],
}

export const counterSlice = createSlice({
  name: "counter",
  initialState,
  reducers: {
    increment: (state) => {
      state.value += 1;
    },
    decrement: (state) => {
      state.value -= 1;
    },
    reset: (state = state) => {
      state.value = 0;
    },
    setPage: (state, action) => {
      state.currentPage = action.payload
    },
    likeRow: (state, action)=> {
      state.likedItems = [...state.likedItems.filter(item=> item !==action.payload), action.payload]
      state.dislikedItems = [...state.dislikedItems.filter(item=> item !==action.payload)]
    },
    dislikeRow: (state, action)=> {
      state.dislikedItems= [...state.dislikedItems.filter(item=> item !==action.payload), action.payload]
      state.likedItems = [...state.likedItems.filter(item=> item !==action.payload)]
    }
  },
  extraReducers: (builder) => {
    builder.addCase(getAndStoreData.pending,(state)=>  {
      state.status = 'pending'
    })
    builder.addCase(getAndStoreData.rejected,(state)=>  {
      state.status = 'error'
    })
    builder.addCase(getAndStoreData.fulfilled,(state, action)=>  {
      state.status = 'fulfilled'
      state.data = action.payload
      state.totalPages = Math.floor(action.payload/LIST_SIZE)
    })
  }
});
export const { decrement, increment, reset, setPage, likeRow, dislikeRow } = counterSlice.actions;
