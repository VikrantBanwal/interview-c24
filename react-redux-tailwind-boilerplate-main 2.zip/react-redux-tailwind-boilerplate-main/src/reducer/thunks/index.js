import { createAsyncThunk } from "@reduxjs/toolkit";
import { fetchData } from "../../client";

export const getAndStoreData = createAsyncThunk('fetch/data', async () => {
  const dataArr = await fetchData();
  return dataArr;
})

